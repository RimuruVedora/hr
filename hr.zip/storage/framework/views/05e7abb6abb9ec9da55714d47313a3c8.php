<!-- Sidebar Column -->
<div class="sidenav col-auto p-0">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/admin-sidebar/sidebar.css', 'resources/js/admin-sidebar/sidebar.js']); ?>
  <div class="sidebar d-flex flex-column justify-content-between shadow-sm border-end">

    <!-- Top Section -->
    <div class="">
      <div class="d-flex justify-content-center align-items-center mb-5 mt-3">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid me-2" style="height: 100px;" alt="ViaHale Logo">
      </div>

      <!-- Main Navigation -->
      <div class="mb-4">
        <h6 class="text-uppercase mb-2">Main</h6>
        <nav class="nav flex-column">
          <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>"><ion-icon name="home-outline"></ion-icon>Dashboard</a>
          <a class="nav-link <?php echo e(request()->routeIs('user.management') ? 'active' : ''); ?>" href="<?php echo e(route('user.management')); ?>"><ion-icon name="people-outline"></ion-icon>User Management</a>
          <div class="dropdown">
            <button type="button" class="nav-link dropdown-toggle" aria-expanded="false"><ion-icon name="newspaper-outline"></ion-icon>Competency</button>
            <div class="dropdown-menu">
              <a class="dropdown-item" href="<?php echo e(route('competency.framework')); ?>"><ion-icon name="layers-outline"></ion-icon>Competency Framework</a>
              <a class="dropdown-item" href="<?php echo e(route('competency.analytics')); ?>"><ion-icon name="analytics-outline"></ion-icon>Competency Analytics</a>
            </div>
          </div>
          <div class="dropdown">
            <button type="button" class="nav-link dropdown-toggle <?php echo e(request()->routeIs('learning.*') ? 'active' : ''); ?>" aria-expanded="false"><ion-icon name="school-outline"></ion-icon>Learning Management</button>
            <div class="dropdown-menu">
              <a class="dropdown-item <?php echo e(request()->routeIs('learning.courses') ? 'active' : ''); ?>" href="<?php echo e(route('learning.courses')); ?>"><ion-icon name="book-outline"></ion-icon>Courses</a>
              <a class="dropdown-item <?php echo e(request()->routeIs('learning.assessments') ? 'active' : ''); ?>" href="<?php echo e(route('learning.assessments')); ?>"><ion-icon name="clipboard-outline"></ion-icon>Assessments</a>
                          <a class="dropdown-item <?php echo e(request()->routeIs('learning.assessment-scores') ? 'active' : ''); ?>" href="<?php echo e(route('learning.assessment-scores')); ?>"><ion-icon name="bar-chart-outline"></ion-icon>Assessment Score</a>
            </div> 
          </div>
         <div class="dropdown">
            <button type="button" class="nav-link dropdown-toggle" aria-expanded="false"><ion-icon name="newspaper-outline"></ion-icon>Training Management</button>
            <div class="dropdown-menu">
              <a class="dropdown-item <?php echo e(request()->routeIs('training.schedule') ? 'active' : ''); ?>" href="<?php echo e(route('training.schedule')); ?>"><ion-icon name="layers-outline"></ion-icon>Training Schedule</a>
              <a class="dropdown-item <?php echo e(request()->routeIs('training.evaluation') ? 'active' : ''); ?>" href="<?php echo e(route('training.evaluation')); ?>"><ion-icon name="analytics-outline"></ion-icon>Evaluation</a>
            </div> 
          </div>
            <div class="dropdown">
            <button type="button" class="nav-link dropdown-toggle" aria-expanded="false"><ion-icon name="newspaper-outline"></ion-icon>Succession Planning</button>
            <div class="dropdown-menu">
              <a class="dropdown-item <?php echo e(request()->routeIs('talent.assessment') ? 'active' : ''); ?>" href="<?php echo e(route('talent.assessment')); ?>"><ion-icon name="layers-outline"></ion-icon>Talent Assessment</a>
              <a class="dropdown-item <?php echo e(request()->routeIs('succession.plans') ? 'active' : ''); ?>" href="<?php echo e(route('succession.plans')); ?>"><ion-icon name="analytics-outline"></ion-icon>Succession Plans</a>
            </div> 
          </div>
        </nav>
      </div>

    <!-- Logout -->
    <div class="p-3 border-top mb-2">
                <a class="nav-link <?php echo e(request()->routeIs('profile') ? 'active' : ''); ?>" href="<?php echo e(route('profile')); ?>"><ion-icon name="person-outline"></ion-icon>Profile</a>
                          <a class="nav-link" href="#"><ion-icon name="settings-outline"></ion-icon>Settings</a>
                          <a class="nav-link <?php echo e(request()->routeIs('sync.index') ? 'active' : ''); ?>" href="<?php echo e(route('sync.index')); ?>"><ion-icon name="sync-outline"></ion-icon>Sync</a>
      <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
        <?php echo csrf_field(); ?>
        <button type="submit" class="nav-link text-danger" style="background: none; border: none; width: 100%; text-align: left;">
          <ion-icon name="log-out-outline"></ion-icon>Logout
        </button>
      </form>
    </div>
  </div>
</div>

<!-- Session Timeout Warning Component -->
<?php echo $__env->make('partials.session-timeout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\hr\resources\views/partials/admin-sidebar.blade.php ENDPATH**/ ?>