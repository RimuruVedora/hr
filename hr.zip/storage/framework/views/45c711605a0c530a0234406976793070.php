<div id="login-config"
     data-auth-needed="<?php echo e(session('auth_needed') ? 'true' : 'false'); ?>"
     data-otp-sent="<?php echo e(session('otp_sent') ? 'true' : 'false'); ?>"
     data-login-lockout="<?php echo e(session('login_lockout') ?? 0); ?>"
     data-otp-resend-route="<?php echo e(route('otp.resend')); ?>"
     style="display: none;">
</div>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/login/login.js'); ?>
<?php /**PATH C:\xampp\htdocs\hr\resources\views/auth/login-scripts.blade.php ENDPATH**/ ?>