<!-- Sidebar Column -->
<div class="sidenav col-auto p-0">
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/admin-sidebar/sidebar.css', 'resources/js/admin-sidebar/sidebar.js']); ?>
  <div class="sidebar d-flex flex-column justify-content-between shadow-sm border-end">

    <!-- Top Section -->
    <div class="">
      <div class="d-flex justify-content-center align-items-center mb-5 mt-3">
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid me-2" style="height: 100px;" alt="ViaHale Logo">
      </div>

      <!-- Main Navigation -->
      <div class="mb-4">
        <h6 class="text-uppercase mb-2">Main</h6>
        <nav class="nav flex-column">
          <a class="nav-link <?php echo e(request()->routeIs('employee.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('employee.dashboard')); ?>"><ion-icon name="home-outline"></ion-icon>Dashboard</a>
          
          <!-- Employee Sections -->
          <a class="nav-link <?php echo e(request()->routeIs('ess.request') ? 'active' : ''); ?>" href="<?php echo e(route('ess.request')); ?>"><ion-icon name="sync-outline"></ion-icon>Document Request</a>
          <div class="dropdown">
            <button type="button" class="nav-link dropdown-toggle <?php echo e(request()->routeIs('learning.*') ? 'active' : ''); ?>" aria-expanded="false"><ion-icon name="school-outline"></ion-icon>My Learning</button>
            <div class="dropdown-menu">
                            <a class="dropdown-item <?php echo e(request()->routeIs('learning.employee.assessments') ? 'active' : ''); ?>" href="<?php echo e(route('learning.employee.assessments')); ?>"><ion-icon name="bar-chart-outline"></ion-icon>All Courses</a>
              <a class="dropdown-item <?php echo e(request()->routeIs('employee.exams') ? 'active' : ''); ?>" href="<?php echo e(route('employee.exams')); ?>"><ion-icon name="book-outline"></ion-icon>My Exams</a>
            </div> 
          </div>

         <div class="dropdown">
            <button type="button" class="nav-link dropdown-toggle <?php echo e(request()->routeIs('training.*') ? 'active' : ''); ?>" aria-expanded="false"><ion-icon name="calendar-outline"></ion-icon>My Training</button>
            <div class="dropdown-menu">
              <a class="dropdown-item <?php echo e(request()->routeIs('training.schedule') ? 'active' : ''); ?>" href="<?php echo e(route('training.schedule')); ?>"><ion-icon name="layers-outline"></ion-icon>My Trainings</a>
            </div> 
          </div>

                  </nav>
      </div>
    </div>

    <!-- Logout -->
    <div class="p-3 border-top mb-2">
                <a class="nav-link <?php echo e(request()->routeIs('profile') ? 'active' : ''); ?>" href="<?php echo e(route('profile')); ?>"><ion-icon name="person-outline"></ion-icon>Profile</a>
                          <a class="nav-link" href="#"><ion-icon name="settings-outline"></ion-icon>Settings</a>
                          <a class="nav-link" href="#"><ion-icon name="sync-outline"></ion-icon>Sync</a>
      <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
        <?php echo csrf_field(); ?>
        <button type="submit" class="nav-link text-danger" style="background: none; border: none; width: 100%; text-align: left;">
          <ion-icon name="log-out-outline"></ion-icon>Logout
        </button>
      </form>
    </div>
  </div>
</div>

<!-- Session Timeout Warning Component -->
<?php echo $__env->make('partials.session-timeout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\hr\resources\views/partials/Employee-sidebar.blade.php ENDPATH**/ ?>