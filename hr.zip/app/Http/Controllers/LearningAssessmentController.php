<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Assessment;
use App\Models\Course;
use App\Models\Competency;
use App\Models\AssessmentQuestion;
use App\Models\AssessmentOption;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

use App\Models\Training;
use App\Models\TrainingParticipant;
use App\Models\EmployeeAssessment;

class LearningAssessmentController extends Controller
{
    public function overallScore()
    {
        // Dashboard Stats
        $totalCourses = Course::count();
        $totalTrainings = Training::count();
        $avgOnlineScore = EmployeeAssessment::whereNotNull('score')->avg('score') ?? 0;
        $avgPhysicalScore = TrainingParticipant::whereNotNull('grade')->avg('grade') ?? 0;

        // Fetch all courses with training count
        $courses = Course::withCount('trainings')->get();

        return view('learning.admin-overall-score', compact(
            'courses', 
            'totalCourses', 
            'totalTrainings', 
            'avgOnlineScore', 
            'avgPhysicalScore'
        ));
    }

    public function getCourseTrainings($courseId)
    {
        $trainings = Training::where('course_id', $courseId)
            ->with(['participants'])
            ->get()
            ->map(function ($training) {
                return [
                    'id' => $training->id,
                    'title' => $training->title ?? 'Training Session', // Training might not have title, usually inherits from Course or has its own? 
                    // Wait, Training model usually has start_date, location, etc.
                    'start_date' => $training->start_date,
                    'end_date' => $training->end_date,
                    'location' => $training->location,
                    'status' => $training->status,
                    'participants_count' => $training->participants->count(),
                ];
            });

        return response()->json($trainings);
    }

    public function getTrainingScores($trainingId)
    {
        $participants = TrainingParticipant::where('training_id', $trainingId)
            ->with(['employee.jobRole'])
            ->get();

        $training = Training::find($trainingId);
        
        $scores = $participants->map(function ($participant) use ($trainingId) {
            $employee = $participant->employee;
            
            // Online Score
            $onlineAssessment = EmployeeAssessment::where('training_id', $trainingId)
                ->where('employee_id', $employee->id)
                ->first();

            return [
                'employee_id' => $employee->id,
                'name' => $employee->first_name . ' ' . $employee->last_name,
                'department' => $employee->department ?? 'N/A',
                'job_role' => $employee->jobRole->name ?? 'N/A',
                'physical_score' => $participant->grade ?? 'N/A',
                'online_score' => $onlineAssessment ? $onlineAssessment->score . '/' . $onlineAssessment->total_items : 'N/A',
                'status' => $participant->status, // Completed, Ongoing, etc.
                'avatar' => $employee->profile_picture ?? null,
            ];
        });

        return response()->json([
            'training_title' => $training->title ?? 'Training Details', // Check Training model for title
            'scores' => $scores
        ]);
    }

    public function employeeAssessments()
    {
        $user = auth()->user();
        
        // Ensure user has an employee record
        if (!$user->employee) {
            // Handle case where admin logs in or no employee record
            return view('learning.Employee-Assessment', ['courses' => []]);
        }

        $employee = $user->employee;
        $departmentId = $user->department_id; // Account has department_id

        // 0. Enrolled Courses (Priority)
        // Fetch trainings the user is participating in
        $enrolledTrainings = \App\Models\TrainingParticipant::where('employee_id', $employee->id)
            ->with(['training.course.competencies', 'training.assessment'])
            ->get()
            ->map(function ($participant) {
                $training = $participant->training;
                $course = $training->course;
                // Attach training info to course for formatting later
                $course->setAttribute('user_enrollment', $participant); 
                $course->setAttribute('user_training', $training);
                return $course;
            });

        // Helper to exclude courses with published trainings (for recommendations)
        // We don't want to recommend "Published" courses unless user is already enrolled (handled above)
        $excludePublished = function ($q) {
            $q->whereDoesntHave('trainings', function ($query) {
                $query->where('status', 'published');
            });
        };

        // 1. Department Courses
        $deptCourses = Course::where('department_id', $departmentId)
            ->where($excludePublished)
            ->with(['competencies', 'assessments'])
            ->get();

        // 2. Competency Gap Courses
        // Find competencies where current_proficiency < target_proficiency
        $gapCompetencyIds = DB::table('employee_competencies')
            ->where('employee_id', $employee->id)
            ->whereRaw('current_proficiency < target_proficiency')
            ->pluck('competency_id');

        $gapCourses = Course::whereHas('competencies', function ($q) use ($gapCompetencyIds) {
            $q->whereIn('competencies.id', $gapCompetencyIds);
        })
        ->where($excludePublished)
        ->with(['competencies', 'assessments'])
        ->get();

        // 3. Succession Planning Courses
        $successionCourses = collect();
        $successionPlan = \App\Models\SuccessionPlan::where('employee_id', $employee->id)
            ->where('status', '!=', 'Completed') // Assuming Active or Pending
            ->first();

        if ($successionPlan && $successionPlan->targetRole) {
            // Get competencies for the target role
            $targetCompetencyIds = DB::table('job_role_competency')
                ->where('job_role_id', $successionPlan->target_role_id)
                ->pluck('competency_id');
            
            $successionCourses = Course::whereHas('competencies', function ($q) use ($targetCompetencyIds) {
                $q->whereIn('competencies.id', $targetCompetencyIds);
            })
            ->where($excludePublished)
            ->with(['competencies', 'assessments'])
            ->get();
        }

        // Merge and Unique (Enrolled first to keep their data)
        $allCourses = $enrolledTrainings
            ->merge($deptCourses)
            ->merge($gapCourses)
            ->merge($successionCourses)
            ->unique('id');

        // Format for Frontend
        $formattedCourses = $allCourses->map(function ($course) {
            $isEnrolled = $course->getAttribute('user_enrollment') !== null;
            $training = $course->getAttribute('user_training');
            
            // Check for available pre-training if not enrolled
            $availableTraining = null;
            $isFull = false;

            if (!$isEnrolled) {
                // Find training that is pre-training (registration open)
                // We use startOfDay() to ensure trainings starting "today" are included regardless of current time
                $availableTraining = \App\Models\Training::where('course_id', $course->id)
                    ->where('status', 'pre_training')
                    ->where('start_date', '>=', now()->startOfDay()) 
                    ->withCount('participants')
                    ->first();
                
                if ($availableTraining) {
                    $isFull = $availableTraining->participants_count >= $availableTraining->capacity;
                }
            }

            $examAccess = false;
            if ($isEnrolled && $training) {
                $now = now();
                if ($training->status === 'published' && $now->between($training->start_date, $training->end_date)) {
                    $examAccess = true;
                }
            }

            // Resolve Assessment Data
            $assessment = null;
            if ($training && $training->assessment) {
                $assessment = $training->assessment;
            } elseif ($course->assessments && $course->assessments->isNotEmpty()) {
                $assessment = $course->assessments->first();
            }

            $examData = [
                'title' => $assessment ? $assessment->title : 'Final Exam',
                'items' => $assessment ? $assessment->questions()->count() : 0,
                'type' => $assessment ? $assessment->type : 'Online',
                'duration' => $assessment ? ($assessment->time_limit . ' Mins') : '60 Mins',
            ];

            return [
                'id' => $course->id,
                'title' => $course->title,
                'category' => $course->category ?? 'General',
                'description' => $course->description,
                'date' => $course->created_at->format('M d, Y'),
                'duration' => $course->duration,
                'skills' => $course->competencies->pluck('name')->toArray(),
                'enrolled' => $isEnrolled,
                'training_id' => $training ? $training->id : null,
                'training_status' => $training ? $training->status : null,
                'start_date' => $training ? $training->start_date->format('M d, Y H:i') : null,
                'end_date' => $training ? $training->end_date->format('M d, Y H:i') : null,
                'exam_access' => $examAccess,
                'has_schedule' => !!$availableTraining, // True if there is a schedule available to enroll
                'is_full' => $isFull,
                'available_training_id' => $availableTraining ? $availableTraining->id : null,
                'materials' => [
                    ['title' => 'Course PDF', 'link' => $course->material_pdf ? asset('storage/' . $course->material_pdf) : '#'],
                ],
                'exam' => $examData
            ];
        })->values(); // Reset keys for JSON array

        return view('learning.Employee-Assessment', ['courses' => $formattedCourses]);
    }

    public function index()
    {
        $assessments = Assessment::with(['course', 'competencies', 'questions'])->get();
        $courses = Course::all();
        $competencies = Competency::all();

        // Transform data for the frontend JS
        $exams = $assessments->map(function ($assessment) {
            // Derive scope and proficiency from competencies or course
            // This is a simplification; you might want to adjust logic based on your actual business rules
            $scope = 'internal'; // Default
            $proficiency = 'beginner'; // Default
            
            if ($assessment->competencies->isNotEmpty()) {
                $scope = $assessment->competencies->first()->scope ?? 'internal';
                $proficiency = $assessment->competencies->first()->proficiency ?? 'beginner';
            }

            return [
                'id' => $assessment->id,
                'course' => $assessment->course ? $assessment->course->title : 'N/A',
                'title' => $assessment->title,
                'scope' => $scope,
                'proficiency' => $proficiency,
                'status' => $assessment->status,
                'items' => $assessment->questions->count(),
                'questions' => $assessment->questions->map(function($q) {
                    return [
                        'id' => $q->id,
                        'text' => $q->question_text,
                        'points' => $q->points,
                        'image' => $q->image_path,
                        'options' => $q->options->map(function($o) {
                            return [
                                'id' => $o->id,
                                'text' => $o->option_text,
                                'is_correct' => $o->is_correct
                            ];
                        })
                    ];
                }),
                'skills' => $assessment->competencies->pluck('name')->join(', '),
                'description' => $assessment->description,
            ];
        });

        return view('learning.admin-assessments', compact('exams', 'courses', 'competencies'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'course_id' => 'required|exists:courses,id',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'type' => 'required|string',
            'status' => 'required|in:draft,published,archived',
            'skills' => 'nullable|string', // Accept skills as a string
            'questions' => 'nullable|array'
        ]);

        return DB::transaction(function () use ($validated) {
            $assessment = Assessment::create([
                'course_id' => $validated['course_id'],
                'title' => $validated['title'],
                'description' => $validated['description'] ?? '',
                'type' => $validated['type'],
                'status' => $validated['status'],
            ]);

            if (!empty($validated['skills'])) {
                $skillNames = array_map('trim', explode(',', $validated['skills']));
                $competencyIds = [];
                
                foreach ($skillNames as $name) {
                    if (empty($name)) continue;
                    
                    $competency = Competency::where('name', 'LIKE', $name)->first();
                    if ($competency) {
                        $competencyIds[] = $competency->id;
                    }
                }
                
                if (!empty($competencyIds)) {
                    $assessment->competencies()->sync($competencyIds);
                }
            }

            if (!empty($validated['questions'])) {
                foreach ($validated['questions'] as $index => $qData) {
                    $imagePath = null;
                    
                    // Handle file upload
                    if (isset($qData['image']) && $qData['image'] instanceof \Illuminate\Http\UploadedFile) {
                        $path = $qData['image']->store('assessment_images', 'public');
                        $imagePath = 'storage/' . $path;
                    }

                    $question = AssessmentQuestion::create([
                        'assessment_id' => $assessment->id,
                        'question_text' => $qData['text'],
                        'question_type' => $qData['type'] ?? 'multiple_choice',
                        'points' => $qData['points'] ?? 1,
                        'image_path' => $imagePath,
                        'order' => $index,
                    ]);

                    if (!empty($qData['options']) && is_array($qData['options'])) {
                        foreach ($qData['options'] as $optIndex => $optData) {
                            AssessmentOption::create([
                                'assessment_question_id' => $question->id,
                                'option_text' => $optData['text'],
                                'is_correct' => filter_var($optData['is_correct'] ?? false, FILTER_VALIDATE_BOOLEAN),
                                'order' => $optIndex,
                            ]);
                        }
                    }
                }
            }

            return response()->json(['success' => true, 'assessment' => $assessment]);
        });
    }

    public function destroy($id)
    {
        $assessment = Assessment::findOrFail($id);
        $assessment->delete();
        return response()->json(['success' => true]);
    }

    public function scores()
    {
        // Fetch all courses with training count
        $courses = Course::withCount('trainings')->get();

        return view('learning.admin-assessment-score', compact('courses'));
    }
}
